<?php
require_once '../config/database.php';
session_start();
if (isset($pdo)) {
    echo "Az adatbázis kapcsolat sikeresen inicializálva!";
} else {
    echo "Hiba: A \$pdo változó nem érhető el.";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id']) && $_SESSION['role'] === 'employer') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $location = $_POST['location'];
    $type = $_POST['type']; // Teljes munkaidő, részmunkaidő, stb.
    $employer_id = $_SESSION['user_id'];

    $sql = "INSERT INTO jobs (employer_id, title, description, location, type, posted_at) 
            VALUES (:employer_id, :title, :description, :location, :type, NOW())";
    $stmt = $pdo->prepare($sql);

    try {
        $stmt->execute([
            ':employer_id' => $employer_id,
            ':title' => $title,
            ':description' => $description,
            ':location' => $location,
            ':type' => $type,
        ]);
        header("Location: ../public/profile.php?message=Álláshirdetés sikeresen létrehozva!");
        exit;
    } catch (PDOException $e) {
        echo "Hiba az álláshirdetés létrehozása során: " . $e->getMessage();
    }
} else {
    header("Location: ../public/login.php");
    exit;
}
?>
