<?php
require_once '../config/database.php';
session_start();

// Adminisztrátor jogosultság ellenőrzése
if ($_SESSION['role'] !== 'admin') {
    echo 'Nincs jogosultságod az adminisztrátori felülethez.';
    exit;
}

if (isset($pdo)) {
    echo "Az adatbázis kapcsolat sikeresen inicializálva!";
} else {
    echo "Hiba: A \$pdo változó nem érhető el.";
}

// Jelentkezések lekérése
$stmt = $pdo->prepare('SELECT applications.*, users.username AS applicant_name, jobs.title AS job_title 
                       FROM applications 
                       JOIN users ON applications.user_id = users.id
                       JOIN jobs ON applications.job_id = jobs.id
                       ORDER BY applications.created_at DESC');
$stmt->execute();
$applications = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Jelentkezések kezelése</title>
</head>
<body>
<h1>Jelentkezések kezelése</h1>

<?php if (count($applications) > 0): ?>
    <table>
        <thead>
        <tr>
            <th>Állás</th>
            <th>Jelentkező</th>
            <th>Jelentkezés dátuma</th>
            <th>Akciók</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($applications as $application): ?>
            <tr>
                <td><?= htmlspecialchars($application['job_title']) ?></td>
                <td><?= htmlspecialchars($application['applicant_name']) ?></td>
                <td><?= htmlspecialchars($application['created_at']) ?></td>
                <td>
                    <a href="view_application.php?id=<?= $application['id'] ?>">Részletek</a>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
<?php else: ?>
    <p>Nincs egyetlen jelentkezés sem.</p>
<?php endif; ?>

</body>
</html>
