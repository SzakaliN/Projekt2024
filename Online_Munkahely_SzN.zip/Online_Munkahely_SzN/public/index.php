<?php
require_once '../config/database.php';

if (isset($pdo)) {
    echo "Az adatbázis kapcsolat sikeresen inicializálva!";
} else {
    echo "Hiba: A \$pdo változó nem érhető el.";
}

// Álláshirdetések lekérése
$stmt = $pdo->query('SELECT * FROM jobs ORDER BY posted_at DESC');
$jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Álláshirdetések</title>
</head>
<body>
<h1>Elérhető állások</h1>

<?php if (count($jobs) > 0): ?>
    <ul>
        <?php foreach ($jobs as $job): ?>
            <li>
                <h2><?= htmlspecialchars($job['title']) ?></h2>
                <p><?= nl2br(htmlspecialchars($job['description'])) ?></p>
                <p><strong>Helyszín:</strong> <?= htmlspecialchars($job['location']) ?></p>
                <p><strong>Típus:</strong> <?= htmlspecialchars($job['type']) ?></p>
                <p><strong>Feladó:</strong> <?= htmlspecialchars($job['employer_id']) ?></p>
                <a href="job_details.php?id=<?= $job['id'] ?>">Tovább</a>
            </li>
        <?php endforeach; ?>
    </ul>
<?php else: ?>
    <p>Nincs elérhető álláshirdetés.</p>
<?php endif; ?>
</body>
</html>
