<?php
require_once '../config/database.php';
session_start();

if (isset($pdo)) {
    echo "Az adatbázis kapcsolat sikeresen inicializálva!";
} else {
    echo "Hiba: A \$pdo változó nem érhető el.";
}

$id = $_GET['id'] ?? 0;

// Ellenőrizzük, hogy a hirdetés ID-ja érvényes
if ($id) {
    // Álláshirdetés adatainak lekérése
    $stmt = $pdo->prepare('SELECT jobs.*, users.username AS employer_name FROM jobs 
                           JOIN users ON jobs.employer_id = users.id 
                           WHERE jobs.id = ?');
    $stmt->execute([$id]);
    $job = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$job) {
        echo 'Az álláshirdetés nem található!';
        exit;
    }
} else {
    echo 'Érvénytelen álláshirdetés!';
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Munkavállalói jelentkezés kezelésére
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
        $job_id = $job['id'];

        // Ellenőrizzük, hogy már jelentkezett-e a felhasználó
        $stmt = $pdo->prepare('SELECT * FROM applications WHERE user_id = ? AND job_id = ?');
        $stmt->execute([$user_id, $job_id]);
        $application = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($application) {
            $error = 'Már jelentkeztél erre az állásra!';
        } else {
            // Jelentkezés mentése az adatbázisba
            $stmt = $pdo->prepare('INSERT INTO applications (user_id, job_id) VALUES (?, ?)');
            if ($stmt->execute([$user_id, $job_id])) {
                $success = 'Sikeresen jelentkeztél erre az állásra!';
            } else {
                $error = 'Hiba történt a jelentkezés során.';
            }
        }
    } else {
        $error = 'Be kell jelentkezned a jelentkezéshez!';
    }
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($job['title']) ?></title>
</head>
<body>
<h1><?= htmlspecialchars($job['title']) ?></h1>

<?php if (isset($error)): ?>
    <p style="color: red;"><?= htmlspecialchars($error) ?></p>
<?php elseif (isset($success)): ?>
    <p style="color: green;"><?= htmlspecialchars($success) ?></p>
<?php endif; ?>

<p><strong>Leírás:</strong> <?= nl2br(htmlspecialchars($job['description'])) ?></p>
<p><strong>Helyszín:</strong> <?= htmlspecialchars($job['location']) ?></p>
<p><strong>Típus:</strong> <?= htmlspecialchars($job['type']) ?></p>
<p><strong>Munkaadó:</strong> <?= htmlspecialchars($job['employer_name']) ?></p>

<?php if (isset($_SESSION['user_id']) && $_SESSION['role'] == 'employee'): ?>
    <!-- Ha a felhasználó munkavállaló és be van jelentkezve, akkor lehetősége van jelentkezni -->
    <form method="post">
        <button type="submit">Jelentkezés</button>
    </form>
<?php elseif (!isset($_SESSION['user_id'])): ?>
    <p><a href="login.php">Jelentkezz be a jelentkezéshez</a></p>
<?php endif; ?>

</body>
</html>
