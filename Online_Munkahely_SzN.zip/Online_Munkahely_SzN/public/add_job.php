<?php
require_once '../config/database.php';
session_start();

if (isset($pdo)) {
    echo "Az adatbázis kapcsolat sikeresen inicializálva!";
} else {
    echo "Hiba: A \$pdo változó nem érhető el.";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'] ?? '';
    $description = $_POST['description'] ?? '';
    $location = $_POST['location'] ?? '';
    $type = $_POST['type'] ?? '';

    // Validáció
    if (empty($title) || empty($description) || empty($location) || empty($type)) {
        $error = 'Minden mezőt ki kell tölteni!';
    } else {
        // Álláshirdetés mentése az adatbázisba
        $stmt = $pdo->prepare('INSERT INTO jobs (title, description, location, type, employer_id) VALUES (?, ?, ?, ?, ?)');
        $stmt->execute([$title, $description, $location, $type, $_SESSION['user_id']]);
        header('Location: index.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Új Álláshirdetés</title>
</head>
<body>
<h1>Új álláshirdetés hozzáadása</h1>

<?php if (isset($error)): ?>
    <p style="color: red;"><?= htmlspecialchars($error) ?></p>
<?php endif; ?>

<form method="post">
    <label>Állás címe: <input type="text" name="title"></label><br>
    <label>Leírás: <textarea name="description"></textarea></label><br>
    <label>Helyszín: <input type="text" name="location"></label><br>
    <label>Típus:
        <select name="type">
            <option value="teljes">Teljes munkaidő</option>
            <option value="reszmunka">Részmunkaidő</option>
        </select>
    </label><br>
    <button type="submit">Hirdetés hozzáadása</button>
</form>
</body>
</html>
