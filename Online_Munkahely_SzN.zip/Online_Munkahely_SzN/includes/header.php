<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Munkahely Portál</title>
    <link rel="stylesheet" href="../css/style.css"> <!-- Ha van CSS fájlod -->
</head>
<body>
<header>
    <h1>Online Munkahely Portál</h1>
</header>
