<footer>
    <p>&copy; 2024 Online Munkahely Portál. Minden jog fenntartva.</p>
</footer>
</body>
</html>
